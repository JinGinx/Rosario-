# rosario-guidato-web
Rosario con voce neurale 
